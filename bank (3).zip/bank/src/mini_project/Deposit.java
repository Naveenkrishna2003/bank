package mini_project;

import java.util.*;
import java.sql.*;

public class Deposit {

    protected long acc_no;
    protected long current_bal;
    protected long depo;
    protected Connection con;
    JDBC jd = new JDBC();

    public long getCurrent_bal() {
        return current_bal;
    }

    public void setCurrent_bal(long current_bal) {
        this.current_bal = current_bal;
    }

    public long getDepo() {
        return depo;
    }

    public void setDepo(long depo) {
        this.depo = depo;
    }

    public long getAcc_no() {
        return acc_no;
    }

    public void setAcc_no(long acc_no) {
        this.acc_no = acc_no;
    }

    public void withdrawFunds(int n) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the account number:");
        this.acc_no = sc.nextInt();

        try {
            con = jd.getcon();

            // Fetch the current balance from the database
            PreparedStatement psGetBalance = con.prepareStatement("SELECT current_bal FROM bal WHERE account_no = ?");
            psGetBalance.setLong(1, acc_no);
            ResultSet rs = psGetBalance.executeQuery();

            if (rs.next()) {
                this.current_bal = rs.getLong("current_bal");
                System.out.println("Current Balance: " + current_bal);

                System.out.println("Enter the amount to be deposited:");
                this.depo = sc.nextLong();

                if (depo <= current_bal) {
                    long updatedBalance = current_bal + depo;

                    // Update the balance in the database
                    PreparedStatement psUpdateBalance = con.prepareStatement("UPDATE bal SET current_bal = ? WHERE account_no = ?");
                    psUpdateBalance.setLong(1, updatedBalance);
                    psUpdateBalance.setLong(2, acc_no);
                    psUpdateBalance.executeUpdate();

                    System.out.println("Deposited Successfull. Updated Balance: " + updatedBalance);
                } 
            } else {
                System.out.println("Account not found.");
            }

            rs.close();
            psGetBalance.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

	
    
}
