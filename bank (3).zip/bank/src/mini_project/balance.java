package mini_project;

import java.util.*;
import java.sql.*;

abstract class balance1 {
    public abstract void check_balance();
}

public class balance extends balance1 {

    private Connection con;
    JDBC jd = new JDBC();

    public void check_balance() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the account number :");

        try {
            con = jd.getcon();
            PreparedStatement ps1 = con.prepareStatement("SELECT current_bal FROM bal WHERE account_no = ?");
            ps1.setLong(1, sc.nextLong());

            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                long currentBal = rs.getLong("current_bal");
                System.out.println("Current Balance: " + currentBal);
            } else {
                System.out.println("Account not found or no balance available.");
            }

            rs.close();
            ps1.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
