package mini_project;
import java.util.*;

public class organisation {
	
	public static void main(String [] args)
	{
		int option=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to NK bank...>>");
		while(true)
		{
			
			System.out.println("Enter 1--->Create Bank Account\nEnter 2---> Deposit Money\nEnter 3--->Withdraw money\nEnter 4--->Check balance\nEnter 5--->Fund Transfer\nEnter 6--->Exit The Application");
			option=sc.nextInt()	;
			if(option==1)
			{
				System.out.println("---------Enter your Details--------");
				customer s=new customer();
				s.createAccount();
				System.out.println("Your details is successfully added.");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==2)
			{
				System.out.println("--------Enter the required details--------");
				Deposit e=new Deposit();
				e.withdrawFunds(1);
				System.out.println("The amount deposited successfully");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==3)
			{
				System.out.println("--------Enter the required details--------");
				withdraw w=new withdraw();
				w.withdrawFunds();
				System.out.println("The amount withdrawn successfully");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==4)
			{
				System.out.println("--------Enter the required details--------");
				balance b=new balance();
				b.check_balance();
				System.out.println("This is your balance");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==5)
			{
				System.out.println("--------Enter the required details--------");
				fund_transfer f=new fund_transfer();
				f.performFundTransfer();
				System.out.println("Fund Transfer done successfully");
				System.out.println("-------------------------------------");
				System.out.println();
			}
			else if(option==6)
			{
				System.out.print("Thank You For Visting");
				System.exit(0);
			}
			else 
			{
				System.out.println("Invalid input");
			}
			
		}
	}
	

}