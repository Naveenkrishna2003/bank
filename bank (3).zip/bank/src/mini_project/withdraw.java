package mini_project;

import java.util.*;
import java.sql.*;

public class withdraw extends Deposit {

    protected Connection con1;
    JDBC jd1 = new JDBC();

    public void withdrawFunds() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the account number:");
        this.acc_no = sc.nextLong();
        System.out.println("Enter the money to be withdrawn");
        this.depo = sc.nextLong();

        try {
            con1 = jd1.getcon();

            // Fetch the current balance from the database
            PreparedStatement psGetBalance = con1.prepareStatement("SELECT current_bal FROM bal WHERE account_no = ?");
            psGetBalance.setLong(1, acc_no);
            ResultSet rs = psGetBalance.executeQuery();

            if (rs.next()) {
                this.current_bal = rs.getLong("current_bal");
                System.out.println("Current Balance: " + current_bal);

                if (depo <= current_bal) {
                    long updatedBalance = current_bal - depo;

                    // Update the balance in the database
                    PreparedStatement psUpdateBalance = con1.prepareStatement("UPDATE bal SET current_bal = ? WHERE account_no = ?");
                    psUpdateBalance.setLong(1, updatedBalance);
                    psUpdateBalance.setLong(2, acc_no);
                    psUpdateBalance.executeUpdate();

                    System.out.println("Withdrawal successful. Updated Balance: " + updatedBalance);
                } else {
                    System.out.println("Insufficient balance for withdrawal.");
                }
            } else {
                System.out.println("Account not found.");
            }

            rs.close();
            psGetBalance.close();
            con1.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
