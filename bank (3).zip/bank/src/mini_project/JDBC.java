package mini_project;
import java.sql.*;

public class JDBC {

	
	String url = "jdbc:mysql://localhost:3306/bank";
	String userName="root";
	String password="Naveensrini5+";
	private Connection con;
	JDBC()
	{
		try
		{
			this.con = DriverManager.getConnection(url, userName, password);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	public Connection getcon()
	{
		return con;
	}
	
}