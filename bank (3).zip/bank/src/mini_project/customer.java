package mini_project;

import java.util.*;
import java.sql.*;

// Step 1: Create an interface for BankAccount
interface BankAccount {
    void createAccount();
}

// Step 2: Make the customer class implement the BankAccount interface
public class customer implements BankAccount {

    private long acc_no;
    private String name;
    private long mobile_number;
    private Connection con;
    private JDBC jd = new JDBC();

    public long getAcc_no() {
        return acc_no;
    }

    public void setAcc_no(long acc_no) {
        this.acc_no = acc_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(long mobile_number) {
        this.mobile_number = mobile_number;
    }

    public long generateAccountNumber() {
        Random random = new Random();
        // Generate a random 5-digit account number
        return 10000 + random.nextInt(90000);
    }

    // Step 3: Implement the createAccount() method from the BankAccount interface
    @Override
    public void createAccount() {
        Scanner sc = new Scanner(System.in);

        this.acc_no = generateAccountNumber();

        System.out.println("Enter your name:");
        this.name = sc.next();

        System.out.println("Enter your mobile number:");
        this.mobile_number = sc.nextLong();

        try {
            con = jd.getcon();

            // Insert the new account holder details into the table
            PreparedStatement ps1 = con.prepareStatement("INSERT INTO account_holder VALUES (?, ?, ?)");
            ps1.setLong(1, acc_no);
            ps1.setString(2, name);
            ps1.setLong(3, mobile_number);
            ps1.executeUpdate();

            // Insert the new account details with initial balance into the table
            PreparedStatement ps2 = con.prepareStatement("INSERT INTO bal VALUES (?, ?)");
            ps2.setLong(1, acc_no);
            ps2.setLong(2, 0);
            ps2.executeUpdate();

            System.out.println("Account created successfully. Account Number: " + acc_no);

            ps1.close();
            ps2.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
