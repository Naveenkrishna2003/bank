/**
 * 
 */
/**
 * @author navee
 *
 */
module bank {
	requires java.sql;
}